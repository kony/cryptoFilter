package com.kony.samples;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.servlet.ServletInputStream;

public class MyRequestStream extends ServletInputStream {

	private String dataString;
	private InputStream bStream;

	public MyRequestStream(String data) {
		super();
		this.dataString = data;
		bStream = new ByteArrayInputStream(this.dataString.getBytes());
	}

	@Override
	public int read() throws IOException {
		return bStream.read();
	}
}
