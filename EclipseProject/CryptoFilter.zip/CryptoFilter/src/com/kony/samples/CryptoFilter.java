package com.kony.samples;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.konylabs.middleware.servlet.filters.IntegrationCustomFilter;

//this will be 10th filter executing, "AppServices" is the servlet name for object services
@IntegrationCustomFilter(filterOrder = 1, servletNames = { "AppServices" })
public class CryptoFilter implements Filter {

	private static final Logger LOGGER = Logger.getLogger(CryptoFilter.class);

	@Override
	public void destroy() {
		// TODO Auto-generated method stub

	}

	@Override
	public void doFilter(ServletRequest arg0, ServletResponse arg1, FilterChain arg2)
			throws IOException, ServletException {
		LOGGER.debug("This is the Object Services Custom Filter : -------> START");

		MyRequestWrapper myRequestObj = new MyRequestWrapper((HttpServletRequest) arg0);

		StringWriter swr = new StringWriter();
		PrintWriter pwrFile = new PrintWriter(swr);

		RecordingResponseWrapper myRespWrapObj = new RecordingResponseWrapper((HttpServletResponse) arg1, pwrFile);

		LOGGER.debug("calling filterchain....");
		arg2.doFilter(myRequestObj, myRespWrapObj);

		LOGGER.debug("Object Services Custom Filter : ---------> END");
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		// TODO Auto-generated method stub

	}

}
