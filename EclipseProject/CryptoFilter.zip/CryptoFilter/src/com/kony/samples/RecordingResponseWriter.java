package com.kony.samples;

import java.io.PrintWriter;
import java.io.Writer;

import org.json.JSONObject;

import com.konylabs.middleware.common.Closer;

public class RecordingResponseWriter extends PrintWriter {
	private PrintWriter responseWriter;
	private String recordedString;

	static char[] plainSpace = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q',
			'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z' };
	static char[] cipherSpace = { 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T',
			'U', 'V', 'W', 'X', 'Y', 'Z', 'A', 'B', 'C' };

	public RecordingResponseWriter(Writer writer, PrintWriter responseWriter) {
		super(writer);
		this.responseWriter = responseWriter;
		recordedString = new String();
	}

	@Override
	public void write(String string, int offset, int length) {

		try {
			JSONObject reJSON = new JSONObject();
			reJSON.put("records", ceasarEncrypt(string));
			reJSON.put("opstatus", 0);
			reJSON.put("httpStatusCode", 0);

			super.write(reJSON.toString(), offset, reJSON.toString().length());

			recordedString += string;

			writeToResponseFile(reJSON.toString(), offset);
		} finally {
			Closer.closeAllQuietly(responseWriter);
		}

	}

	public void writeToResponseFile(String string, int offset) {
		responseWriter.write(string, offset, string.length());
	}

	public String getWriterRecordedString() {
		return this.recordedString;
	}

	@Override
	public void flush() {
		super.flush();
	}

	private static String ceasarEncrypt(String plainText) {
		System.out.println("=> plaintext : " + plainText);

		plainText = plainText.toLowerCase();
		char[] plainBits = plainText.toCharArray();
		String ciphText = "";

		for (char plainBit : plainBits) {
			int pIndex = indexOf(plainSpace, plainBit);
			if (pIndex != -1) {
				ciphText += cipherSpace[pIndex];
			} else {
				ciphText += plainBit;
			}
		}

		System.out.println("=> ciphertext : " + ciphText);
		return ciphText;
	}

	private static int indexOf(char[] sequence, char key) {
		for (int i = 0; i < sequence.length; i++) {
			if (key == sequence[i]) {
				return i;
			}
		}
		return -1;
	}
}
