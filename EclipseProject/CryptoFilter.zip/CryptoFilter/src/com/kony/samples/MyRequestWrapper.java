package com.kony.samples;

import java.io.IOException;

import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

import org.json.JSONObject;

public class MyRequestWrapper extends HttpServletRequestWrapper {

	private ServletInputStream actualStream;
	private ServletInputStream decryptedStream;

	static char[] plainSpace = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q',
			'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z' };
	static char[] cipherSpace = { 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T',
			'U', 'V', 'W', 'X', 'Y', 'Z', 'A', 'B', 'C' };

	public MyRequestWrapper(HttpServletRequest request) throws IOException {
		super(request);

		actualStream = request.getInputStream();

		int ina = actualStream.read();
		String streamData = new String("");
		while (ina != -1) {
			streamData += (char) ina;
			ina = actualStream.read();
		}
		if (streamData.length() == "".length()) {
			decryptedStream = actualStream;
		} else {
			System.out.println("stream data is :" + streamData);
			// ToDo stuff
			try {
				JSONObject enStremObj = new JSONObject(streamData);

				String dataToDecrypt = enStremObj.getString("enData");

				JSONObject decryptedJson = new JSONObject(ceasarDecrypt(dataToDecrypt));

				decryptedStream = new MyRequestStream(decryptedJson.toString());
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	@Override
	public ServletInputStream getInputStream() throws IOException {
		// TODO Auto-generated method stub

		return decryptedStream;
	}

	private static String ceasarDecrypt(String cipText) {
		System.out.println("=> ciphtext : " + cipText);

		cipText = cipText.toUpperCase();
		char cipBits[] = cipText.toCharArray();

		String plainText = "";
		for (char cipBit : cipBits) {
			int cIndex = indexOf(cipherSpace, cipBit);
			if (cIndex != -1) {
				plainText += plainSpace[cIndex];
			} else {
				plainText += cipBit;
			}
		}
		System.out.println("=> plainertext : " + plainText);
		return plainText;
	}

	private static int indexOf(char[] sequence, char key) {
		for (int i = 0; i < sequence.length; i++) {
			if (key == sequence[i]) {
				return i;
			}
		}
		return -1;
	}
}
