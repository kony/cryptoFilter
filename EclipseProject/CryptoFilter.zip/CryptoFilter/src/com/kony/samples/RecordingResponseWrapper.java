package com.kony.samples;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletResponseWrapper;

public class RecordingResponseWrapper extends HttpServletResponseWrapper {

	private PrintWriter writer;
	private RecordingResponseWriter awriter;

	public RecordingResponseWrapper(HttpServletResponse response, PrintWriter responseWriter) throws IOException {

		super(response);
		awriter = new RecordingResponseWriter(response.getWriter(), responseWriter);
		writer = awriter;

	}

	@Override
	public PrintWriter getWriter() {
		return writer;
	}

	public String getRecordedContent() {
		return awriter.getWriterRecordedString();
	}

}
