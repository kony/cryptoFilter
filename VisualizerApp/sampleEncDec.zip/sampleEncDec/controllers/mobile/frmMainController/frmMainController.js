define({ 

 //Type your controller code here 
		getAcData:function()
  		{
          	var ddd = new Date();
    		var toBeSent = {};    
            function successCB(dataModel) {
                var userDataObject = new kony.sdk.dto.DataObject("details");
                userDataObject.setRecord(toBeSent);
                var params = {
                    "dataObject": userDataObject
                	};
				
              dataModel.fetch(params, function (successResponse) {
                
                      kony.model.ApplicationContext.dismissLoadingScreen();
                	  alert("fetch successfully!!!! :"+successResponse);                	
                		var data = JSON.parse(ceasarDecrypt(successResponse));
                		data = data.records;
                		this.view.segAcList.widgetDataMap = {"lblName":"std_name","lblAcNum":"std_contact","lblBal":"std_id"};
						this.view.segAcList.setData(data);                
					}.bind(this),
					function (errorResponse) {
                          kony.model.ApplicationContext.dismissLoadingScreen();
                          alert("failure" + JSON.stringify(errorResponse));
                          });
              
		}
		function errorCB(err) {
         
          	kony.model.ApplicationContext.dismissLoadingScreen();
			alert("error in create model" + JSON.stringify(err));
		}
		
    	try {
			kony.application.showLoadingScreen("","fetch data started...", constants.LOADING_SCREEN_POSITION_ONLY_CENTER, true, true,null);
          	kony.model.ApplicationContext.createModel("details", "MyStudents", {
					"access": "online"
				}, {}, successCB.bind(this), errorCB);
		} catch (exp) {
			kony.model.ApplicationContext.dismissLoadingScreen();
			alert("Exception while creating data model");
		}
     }
 });