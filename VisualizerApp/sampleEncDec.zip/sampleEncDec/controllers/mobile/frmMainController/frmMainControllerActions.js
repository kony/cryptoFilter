define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Button_jf0445237e1e4980b62a00537914ca3c: function AS_Button_jf0445237e1e4980b62a00537914ca3c(eventobject) {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmAddAc");
        ntf.navigate();
    },
    AS_Form_a346d1af79ff44f9832c8b5da7fca29c: function AS_Form_a346d1af79ff44f9832c8b5da7fca29c(eventobject) {
        var self = this;
        this.getAcData();
        //invokeNodeService("http://192.168.0.4","7777",{},this.myNodeResp);
        //this.nodeFetchStudents();
    }
});