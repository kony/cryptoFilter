define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Button_jba5d06ff0934494bd2af5a3628d7b71: function AS_Button_jba5d06ff0934494bd2af5a3628d7b71(eventobject) {
        var self = this;
        this.onClickAdd();
    }
});