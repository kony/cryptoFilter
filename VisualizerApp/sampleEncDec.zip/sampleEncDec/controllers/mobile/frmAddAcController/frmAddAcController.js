define({ 

 //Type your controller code here 
  
  onClickAdd:function()
  {
    //alert("need to check!!!");
            var ddd = new Date();
			var data = "{'std_name':'"+this.view.txtName.text+"','std_contact':'"+ this.view.txtBalance.text+"'}";
    		//alert("actual data :"+JSON.stringify(data));
    		var enData = ceasarEncrypt(data);
    		alert("encrypted :"+enData);
    		var toBeSent = {"enData":enData};   
            function successCB(dataModel) {
                var userDataObject = new kony.sdk.dto.DataObject("cust_profile");
                userDataObject.setRecord(toBeSent);
                var params = {
                    "dataObject": userDataObject
                	};
              dataModel.create(params, function (successResponse) {
                
                      kony.model.ApplicationContext.dismissLoadingScreen();
                      alert("created successfully!!!!");
                      
					},
					function (errorResponse) {
                          kony.model.ApplicationContext.dismissLoadingScreen();
                          alert("failure" + JSON.stringify(errorResponse));
                          });
              alert("decrypted  :"+caesarDecrypt(toBeSent.d));
		}
		function errorCB(err) {
         
          	kony.model.ApplicationContext.dismissLoadingScreen();
			alert("error in create model" + JSON.stringify(err));
		}
		
    	try {
			kony.application.showLoadingScreen("","create data started...", constants.LOADING_SCREEN_POSITION_ONLY_CENTER, true, true,null);		
          	kony.model.ApplicationContext.createModel("details", "MyStudents", {
					"access": "online"
				}, {}, successCB.bind(this), errorCB);
		} catch (exp) {
			kony.model.ApplicationContext.dismissLoadingScreen();
			alert("Exception while creating data model");
		}
  }
 });