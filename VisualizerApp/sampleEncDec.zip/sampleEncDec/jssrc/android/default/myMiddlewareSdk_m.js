//autor : baba
//  mysdk ersion
var myMiddleWare;
var processCallback;

function invokeNodeService(host, port, data, callBack) {
    kony.application.showLoadingScreen("", "fetching Data...", constants.LOADING_SCREEN_POSITION_ONLY_CENTER, true, true, null);
    var myMiddlewareUrl = host + ":" + port + "/mymiddleware/services";
    processCallback = callBack;
    var request = new kony.net.HttpRequest();
    myMiddleWare = request;
    request.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    var frmReqData = new kony.net.FormData();
    frmReqData.append("dataObjectString", JSON.stringify(data));
    request.onReadyStateChange = httpTokenReadyStateCallBack;
    request.open(constants.HTTP_METHOD_POST, myMiddlewareUrl);
    request.send();
}

function httpTokenReadyStateCallBack() {
    if (myMiddleWare.readyState === constants.HTTP_READY_STATE_DONE) {
        var myResponse = myMiddleWare.response;
        kony.application.dismissLoadingScreen();
        processCallback(myResponse);
    }
}