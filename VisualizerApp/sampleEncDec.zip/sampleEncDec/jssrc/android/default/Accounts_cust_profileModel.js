/*
 * Model class for cust_profile object under Accounts object service group
 * This is generated file. Please do not edit.
 *
 */
kony = kony || {};
kony.model = kony.model || {};
kony.model.Accounts = kony.model.Accounts || {};
/**
 * Creates a new Model.
 * @class cust_profileModel
 * @param {Object} applicationContext - Application Context.
 * @param {Object} entityMetaData - Entity Metadata.
 * @param {Object} configOptions - Service Name and Service Options.
 */
kony.model.Accounts.cust_profileModel = (function() {
    function cust_profileModel(applicationContext, entityMetaData, configOptions) {
        /**
         * @Fields in this object
         *
         * ac_number 
         * customer_name 
         * customer_contact 
         * CreatedBy 
         * LastUpdatedBy 
         * CreatedDateTime 
         * LastUpdatedDateTime 
         * SoftDeleteFlag 
         */
        kony.model.BaseModel.call(this, applicationContext, entityMetaData, configOptions);
    }
    inheritsFrom(cust_profileModel, kony.model.BaseModel);
    /**
     * This method returns requested property of column from metadata.
     * @memberof cust_profileModel#
     * @param {String} columnName - Column Name.
     * @param {String} key - property of column.
     * @returns {Object} - Value for property 
     */
    cust_profileModel.prototype.getValueForColumnProperty = function(columnName, key) {
            return kony.model.BaseModel.prototype.getValueForColumnProperty.call(this, columnName, key);
        }
        /**
         * This method returns list of column names for this object from metadata.
         * @memberof cust_profileModel#
         * @returns {Array} - List of columns
         */
    cust_profileModel.prototype.getColumnNames = function() {
            return kony.model.BaseModel.prototype.getColumnNames.call(this);
        }
        /**
         * This method returns requested property of this object from metadata.
         * @memberof cust_profileModel#
         * @param {String} propertyName - property.
         * @returns {Object} - Value for property 
         */
    cust_profileModel.prototype.getValueForProperty = function(propertyName) {
            return kony.model.BaseModel.prototype.getValueForProperty.call(this, propertyName);
        }
        /**
         * This method returns properties map of column from metadata.
         * @memberof cust_profileModel#
         * @param {String} columnName - Column Name.
         * @returns {Object} - Column information 
         */
    cust_profileModel.prototype.getColumnInfo = function(columnName) {
            return kony.model.BaseModel.prototype.getColumnInfo.call(this, columnName);
        }
        /**
         * This method returns picklist values if exists for column from metadata.
         * @memberof cust_profileModel#
         * @param {String} columnName - Column Name.
         * @returns {Array} - Pick list values for column
         */
    cust_profileModel.prototype.getFieldPickListValues = function(columnName) {
            return kony.model.BaseModel.prototype.getFieldPickListValues.call(this, columnName);
        }
        /**
         * This method fetches the data for requested columns of this object.
         * @memberof cust_profileModel#
         * @param {Array} columnNames - List of Columns.
         * @param {SuccessCallback} onSuccess - Success Callback.
         * @param {SuccessCallback} onError - Error Callback.
         * @param {Object} [dataModel] - DataModel, (applies filter if contains primary key value map).
         */
    cust_profileModel.prototype.fetchDataForColumns = function(columnNames, onSuccess, onError, dataModel) {
            kony.model.BaseModel.prototype.fetchDataForColumns.call(this, columnNames, onSuccess, onError, dataModel);
        }
        /**
         * This method fetches the data of this object as requested in dataObject
         * @memberof cust_profileModel#
         * @param {Object} options - includes {"dataObject": kony.sdk.dto.DataObject}
         * @param {SuccessCallback} onSuccess - Success Callback.
         * @param {SuccessCallback} onError - Error Callback.
         */
    cust_profileModel.prototype.fetch = function(options, onSuccess, onError) {
            kony.model.BaseModel.prototype.fetch.call(this, options, onSuccess, onError);
        }
        /**
         * This method saves the record provided in dataObject.
         * @memberof cust_profileModel#
         * @param {Object} options - includes {"dataObject": kony.sdk.dto.DataObject}
         * @param {SuccessCallback} onSuccess - Success Callback.
         * @param {SuccessCallback} onError - Error Callback.
         */
    cust_profileModel.prototype.create = function(options, onSuccess, onError) {
            kony.model.BaseModel.prototype.create.call(this, options, onSuccess, onError);
        }
        /**
         * This method updates the columns of record provided in dataObject.
         * @memberof cust_profileModel#
         * @param {Object} options - includes {"dataObject": kony.sdk.dto.DataObject}
         * @param {SuccessCallback} onSuccess - Success Callback.
         * @param {SuccessCallback} onError - Error Callback.
         */
    cust_profileModel.prototype.update = function(options, onSuccess, onError) {
            kony.model.BaseModel.prototype.update.call(this, options, onSuccess, onError);
        }
        /**
         * This method updates the columns of record provided in dataObject.
         * @memberof cust_profileModel#
         * @param {Object} options - includes {"dataObject": kony.sdk.dto.DataObject}
         * @param {SuccessCallback} onSuccess - Success Callback.
         * @param {SuccessCallback} onError - Error Callback.
         */
    cust_profileModel.prototype.partialUpdate = function(options, onSuccess, onError) {
            kony.model.BaseModel.prototype.partialUpdate.call(this, options, onSuccess, onError);
        }
        /**
         * This method updates(overrides) the record provided in dataObject.
         * @memberof cust_profileModel#
         * @param {Object} options - includes {"dataObject": kony.sdk.dto.DataObject}
         * @param {SuccessCallback} onSuccess - Success Callback.
         * @param {SuccessCallback} onError - Error Callback.
         */
    cust_profileModel.prototype.completeUpdate = function(options, onSuccess, onError) {
            kony.model.BaseModel.prototype.completeUpdate.call(this, options, onSuccess, onError);
        }
        /**
         * This method removes the record provided in dataObject.
         * @memberof cust_profileModel#
         * @param {Object} options - includes {"dataObject": kony.sdk.dto.DataObject}
         * @param {SuccessCallback} onSuccess - Success Callback.
         * @param {SuccessCallback} onError - Error Callback.
         */
    cust_profileModel.prototype.remove = function(options, onSuccess, onError) {
            kony.model.BaseModel.prototype.remove.call(this, options, onSuccess, onError);
        }
        /**
         * This method removes the record in this object with provided primary key values.
         * @memberof cust_profileModel#
         * @param {Object} primaryKeyValueMap - Primary Keys and values.
         * @param {SuccessCallback} onSuccess - Success Callback.
         * @param {SuccessCallback} onError - Error Callback.
         */
    cust_profileModel.prototype.removeByPrimaryKey = function(primaryKeyValueMap, onSuccess, onError) {
            kony.model.BaseModel.prototype.removeByPrimaryKey.call(this, primaryKeyValueMap, onSuccess, onError);
        }
        /**
         * This method fetches the complete response of fetch operation as requested in dataObject
         * @memberof cust_profileModel#
         * @param {Object} options - includes {"dataObject": kony.sdk.dto.DataObject}
         * @param {SuccessCallback} onSuccess - Success Callback.
         * @param {SuccessCallback} onError - Error Callback.
         */
    cust_profileModel.prototype.fetchResponse = function(options, onSuccess, onError) {
            kony.model.BaseModel.prototype.fetchResponse.call(this, options, onSuccess, onError);
        }
        /**
         * This method invokes the customVerb operation as requested in dataObject
         * @memberof cust_profileModel#
         * @param {String} verbName - Name of the verb
         * @param {Object} options - includes {"dataObject": kony.sdk.dto.DataObject}
         * @param {SuccessCallback} onSuccess - Success Callback.
         * @param {SuccessCallback} onError - Error Callback.
         */
    cust_profileModel.prototype.customVerb = function(verbName, options, success, error) {
            kony.model.BaseModel.prototype.customVerb.call(this, verbName, options, success, error);
        }
        /**
         * This invokes the validate method in model extension class.
         * This is called from create and update methods.
         * @memberof cust_profileModel#
         * @param {Object} dataObject - Data object.
         * @param {kony.model.ValidationType} validationType - Create/Update.
         * @returns {Boolean} - whether data is valid
         */
    cust_profileModel.prototype.validate = function(dataObject, validationType) {
        return kony.model.BaseModel.prototype.validate.call(this, dataObject, validationType);
    }
    return cust_profileModel;
})();