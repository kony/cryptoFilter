define("frmMain", function() {
    return function(controller) {
        function addWidgetsfrmMain() {
            this.setDefaultUnit(kony.flex.DP);
            var flxList = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "82%",
                "id": "flxList",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "skin": "CopyslFbox0a4ee205d48de4b",
                "top": "10%",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxList.setDefaultUnit(kony.flex.DP);
            var segAcList = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "data": [{
                    "lblAcNum": "Label",
                    "lblBal": "Label",
                    "lblName": "Label"
                }, {
                    "lblAcNum": "Label",
                    "lblBal": "Label",
                    "lblName": "Label"
                }, {
                    "lblAcNum": "Label",
                    "lblBal": "Label",
                    "lblName": "Label"
                }],
                "groupCells": false,
                "height": "98%",
                "id": "segAcList",
                "isVisible": true,
                "left": "0%",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": "flxOutr",
                "scrollingEvents": {},
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "1%",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxBody": "flxBody",
                    "flxOutr": "flxOutr",
                    "lblAcNum": "lblAcNum",
                    "lblBal": "lblBal",
                    "lblName": "lblName"
                },
                "width": "100%",
                "zIndex": 1
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxList.add(segAcList);
            var lbl = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "5%",
                "id": "lbl",
                "isVisible": true,
                "left": "148dp",
                "skin": "CopyslLabel0e78134ec52154b",
                "text": "Students List",
                "textStyle": {
                    "letterSpacing": 0,
                    "strikeThrough": false
                },
                "top": "12dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false
            });
            var btnAddAc = new kony.ui.Button({
                "bottom": "0%",
                "centerX": "50%",
                "focusSkin": "slButtonGlossRed",
                "height": "8%",
                "id": "btnAddAc",
                "isVisible": true,
                "onClick": controller.AS_Button_jf0445237e1e4980b62a00537914ca3c,
                "skin": "slButtonGlossBlue",
                "text": "Add Account",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            this.add(flxList, lbl, btnAddAc);
        };
        return [{
            "addWidgets": addWidgetsfrmMain,
            "enabledForIdleTimeout": false,
            "id": "frmMain",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "postShow": controller.AS_Form_a346d1af79ff44f9832c8b5da7fca29c,
            "skin": "CopyslForm0d0b21b04ead145"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "footerOverlap": false,
            "headerOverlap": false,
            "menuPosition": constants.FORM_MENU_POSITION_AFTER_APPMENU,
            "retainScrollPosition": false,
            "titleBar": true,
            "titleBarSkin": "slTitleBar",
            "windowSoftInputMode": constants.FORM_ADJUST_PAN
        }]
    }
});