define({
    "getAcData": function() {
        var ddd = new Date();
        var toBeSent = {};

        function successCB(dataModel) {
            var userDataObject = new kony.sdk.dto.DataObject("details");
            userDataObject.setRecord(toBeSent);
            var params = {
                "dataObject": userDataObject
            };
            dataModel.fetch(params, function(successResponse) {
                kony.model.ApplicationContext.dismissLoadingScreen();
                alert("fetch successfully!!!! :" + successResponse);
                var data = JSON.parse(ceasarDecrypt(successResponse));
                data = data.records;
                this.view.segAcList.widgetDataMap = {
                    "lblName": "std_name",
                    "lblAcNum": "std_contact",
                    "lblBal": "std_id"
                };
                this.view.segAcList.setData(data);
            }.bind(this), function(errorResponse) {
                kony.model.ApplicationContext.dismissLoadingScreen();
                alert("failure" + JSON.stringify(errorResponse));
            });
        }

        function errorCB(err) {
            kony.model.ApplicationContext.dismissLoadingScreen();
            alert("error in create model" + JSON.stringify(err));
        }
        try {
            kony.application.showLoadingScreen("", "fetch data started...", constants.LOADING_SCREEN_POSITION_ONLY_CENTER, true, true, null);
            kony.model.ApplicationContext.createModel("details", "MyStudents", {
                "access": "online"
            }, {}, successCB.bind(this), errorCB);
        } catch (exp) {
            kony.model.ApplicationContext.dismissLoadingScreen();
            alert("Exception while creating data model");
        }
    },
    "AS_Button_jf0445237e1e4980b62a00537914ca3c": function AS_Button_jf0445237e1e4980b62a00537914ca3c(eventobject) {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmAddAc");
        ntf.navigate();
    },
    "AS_Form_a346d1af79ff44f9832c8b5da7fca29c": function AS_Form_a346d1af79ff44f9832c8b5da7fca29c(eventobject) {
        var self = this;
        this.getAcData();
        //invokeNodeService("http://192.168.0.4","7777",{},this.myNodeResp);
        //this.nodeFetchStudents();
    }
})