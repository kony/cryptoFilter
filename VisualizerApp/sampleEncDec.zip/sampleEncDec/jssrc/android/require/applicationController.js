define({
    appInit: function(params) {
        skinsInit();
        kony.mvc.registry.add("flxOutr", "flxOutr", "flxOutrController");
        kony.mvc.registry.add("frmAddAc", "frmAddAc", "frmAddAcController");
        kony.mvc.registry.add("frmMain", "frmMain", "frmMainController");
        setAppBehaviors();
        if (typeof startBackgroundWorker != "undefined") {
            startBackgroundWorker();
        }
    },
    postAppInitCallBack: function() {},
    appmenuseq: function() {
        new kony.mvc.Navigation("frmMain").navigate();
    }
});