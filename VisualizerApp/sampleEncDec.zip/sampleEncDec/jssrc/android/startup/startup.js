//startup.js file
var globalhttpheaders = {};
var appConfig = {
    appId: "sampleEncDec",
    appName: "asmpleEncDec",
    appVersion: "1.0.0",
    platformVersion: null,
    serverIp: "10.10.33.79",
    serverPort: "80",
    secureServerPort: "443",
    isDebug: true,
    middlewareContext: "sampleEncDec",
    isturlbase: "http://kh2183.kitspl.com:8282/services",
    isMFApp: true,
    appKey: "3e9b2bfb5c6bcc05528e1415a8295aeb",
    appSecret: "8a2eef90648f507c5713ef4ff77815ff",
    serviceUrl: "http://kh2183.kitspl.com:8282/authService/100000002/appconfig",
    svcDoc: {
        "appId": "0042b6ca-217f-408e-813f-11a6cb850567",
        "baseId": "9ff2a1ac-3574-4140-b562-ce35848d392f",
        "name": "cryptoFilterSample",
        "selflink": "http://kh2183.kitspl.com:8282/authService/100000002/appconfig",
        "integsvc": {
            "Dummy": "http://kh2183.kitspl.com:8282/services/Dummy"
        },
        "reportingsvc": {
            "custom": "http://kh2183.kitspl.com:8282/services/CMS",
            "session": "http://kh2183.kitspl.com:8282/services/IST"
        },
        "services_meta": {
            "Dummy": {
                "version": "1.0",
                "url": "http://kh2183.kitspl.com:8282/services/Dummy",
                "type": "integsvc"
            },
            "MyStudents": {
                "version": "1.0",
                "url": "http://kh2183.kitspl.com:8282/services/data/v1/MyStudents",
                "metadata_url": "http://kh2183.kitspl.com:8282/services/metadata/v1/MyStudents",
                "type": "objectsvc"
            }
        }
    },
    svcDocRefresh: false,
    svcDocRefreshTimeSecs: -1,
    eventTypes: ["FormEntry", "ServiceRequest", "Error", "Crash"],
    url: "http://kh2183.kitspl.com:8282/admin/sampleEncDec/MWServlet",
    secureurl: "http://kh2183.kitspl.com:8282/admin/sampleEncDec/MWServlet"
};
sessionID = "";

function appInit(params) {
    skinsInit();
    setAppBehaviors();
};

function setAppBehaviors() {
    kony.application.setApplicationBehaviors({
        applyMarginPaddingInBCGMode: false,
        adherePercentageStrictly: true,
        retainSpaceOnHide: true,
        isMVC: true,
        marginsIncludedInWidgetContainerWeight: true,
        APILevel: 7300
    })
};

function themeCallBack() {
    initializeGlobalVariables();
    applicationController = require("applicationController");
    callAppMenu();
    kony.application.setApplicationInitializationEvents({
        init: applicationController.appInit,
        showstartupform: function() {
            var startForm = new kony.mvc.Navigation("frmMain");
            startForm.navigate();
        }
    });
};

function loadResources() {
    globalhttpheaders = {};
    sdkInitConfig = {
        "appConfig": appConfig,
        "isMFApp": appConfig.isMFApp,
        "appKey": appConfig.appKey,
        "appSecret": appConfig.appSecret,
        "eventTypes": appConfig.eventTypes,
        "serviceUrl": appConfig.serviceUrl
    }
    kony.setupsdks(sdkInitConfig, onSuccessSDKCallBack, onSuccessSDKCallBack);
};

function onSuccessSDKCallBack() {
    kony.theme.setCurrentTheme("default", themeCallBack, themeCallBack);
}
kony.application.setApplicationMode(constants.APPLICATION_MODE_NATIVE);
//If default locale is specified. This is set even before any other app life cycle event is called.
loadResources();
// If you wish to debug Application Initialization events, now is the time to
// place breakpoints.
debugger;