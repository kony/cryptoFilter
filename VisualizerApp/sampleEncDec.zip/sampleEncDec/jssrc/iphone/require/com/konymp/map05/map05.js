define(function() {
    return function(controller) {
        var map05 = new kony.ui.FlexContainer({
            "clipBounds": true,
            "isMaster": true,
            "height": "100%",
            "id": "map05",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "preShow": controller.AS_FlexContainer_ec0cbdcd58ed443788cf8ebd99b42932,
            "skin": "CopyslFbox",
            "top": "0dp",
            "width": "100%"
        }, {}, {});
        map05.setDefaultUnit(kony.flex.DP);
        var mapView = new kony.ui.Map({
            "calloutWidth": 80,
            "defaultPinImage": "kony_mp_map05_red_pin.png",
            "height": "100%",
            "id": "mapView",
            "isVisible": true,
            "left": "0dp",
            "onPinClick": controller.AS_Map_a4e71df2f34e4ca2b0458fbadc02c8e3,
            "provider": constants.MAP_PROVIDER_GOOGLE,
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, {}, {
            "mode": constants.MAP_VIEW_MODE_NORMAL,
            "showCurrentLocation": constants.MAP_VIEW_SHOW_CURRENT_LOCATION_NONE,
            "zoomLevel": 6
        });
        var flxParent = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "100%",
            "id": "flxParent",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "onTouchStart": controller.AS_FlexContainer_b1697257ac6b424789b3e8ebce21f5ac,
            "skin": "CopyslFbox",
            "top": "86.50%",
            "width": "100%",
            "zIndex": 3
        }, {}, {});
        flxParent.setDefaultUnit(kony.flex.DP);
        var flxMain = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "70%",
            "id": "flxMain",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0.00%",
            "skin": "CopyslFbox",
            "top": "0%",
            "width": "100%",
            "zIndex": 1
        }, {}, {});
        flxMain.setDefaultUnit(kony.flex.DP);
        var flxHeader = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "21%",
            "id": "flxHeader",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "onTouchStart": controller.AS_FlexContainer_fd62abe9b95343e4891e7b7d4c81f070,
            "skin": "CopyslFbox",
            "top": "0dp",
            "width": "100%",
            "zIndex": 2
        }, {}, {});
        flxHeader.setDefaultUnit(kony.flex.DP);
        flxHeader.add();
        var flxBody = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "79%",
            "id": "flxBody",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "skin": "konympmap05sknFlxWhite",
            "top": "21%",
            "width": "100%",
            "zIndex": 1
        }, {}, {});
        flxBody.setDefaultUnit(kony.flex.DP);
        flxBody.add();
        var lblOpenHours = new kony.ui.Label({
            "id": "lblOpenHours",
            "isVisible": true,
            "left": "5.50%",
            "skin": "konympmap05BlackBold",
            "text": "Open Hours:",
            "top": "23.70%",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "textCopyable": false,
            "wrapping": constants.WIDGET_TEXT_WORD_WRAP
        });
        var lblOpenHoursMonToFri = new kony.ui.Label({
            "id": "lblOpenHoursMonToFri",
            "isVisible": true,
            "left": "5.50%",
            "skin": "konympmap05sknLbl575757FontSize100",
            "text": "Monday-Friday",
            "top": "31%",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "textCopyable": false,
            "wrapping": constants.WIDGET_TEXT_WORD_WRAP
        });
        var lblOpenHoursMonToFriValue = new kony.ui.Label({
            "id": "lblOpenHoursMonToFriValue",
            "isVisible": true,
            "left": "5.50%",
            "skin": "konympmap05sknLblBlack107SFRegular",
            "text": "7:30AM - 11:00PM",
            "top": "36%",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "textCopyable": false,
            "wrapping": constants.WIDGET_TEXT_WORD_WRAP
        });
        var lblOpenHoursSatToSun = new kony.ui.Label({
            "id": "lblOpenHoursSatToSun",
            "isVisible": true,
            "left": "5.50%",
            "skin": "konympmap05sknLbl575757FontSize100",
            "text": "Saturday-Sunday",
            "top": "43%",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "textCopyable": false,
            "wrapping": constants.WIDGET_TEXT_WORD_WRAP
        });
        var lblOpenHoursSatToSunValue = new kony.ui.Label({
            "id": "lblOpenHoursSatToSunValue",
            "isVisible": true,
            "left": "5.50%",
            "skin": "konympmap05sknLblBlack107SFRegular",
            "text": "9:00AM - 9:00PM",
            "top": "48%",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "textCopyable": false,
            "wrapping": constants.WIDGET_TEXT_WORD_WRAP
        });
        var line1 = new kony.ui.Label({
            "height": "0.05%",
            "id": "line1",
            "isVisible": true,
            "left": "0%",
            "skin": "konympmap05sknLblGreyBackground",
            "top": "55.50%",
            "width": "100%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "textCopyable": false,
            "wrapping": constants.WIDGET_TEXT_WORD_WRAP
        });
        var flxCall = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "22%",
            "id": "flxCall",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0%",
            "skin": "CopyslFbox",
            "top": "55%",
            "width": "33.33%",
            "zIndex": 1
        }, {}, {});
        flxCall.setDefaultUnit(kony.flex.DP);
        var imgCall = new kony.ui.Image2({
            "centerX": "50%",
            "centerY": "30%",
            "height": "40dp",
            "id": "imgCall",
            "isVisible": true,
            "left": "12dp",
            "skin": "slImage",
            "src": "kony_mp_map05_call.png",
            "top": "10dp",
            "width": "40dp",
            "zIndex": 1
        }, {
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var lblCall = new kony.ui.Label({
            "centerX": "52%",
            "centerY": "70%",
            "id": "lblCall",
            "isVisible": true,
            "skin": "konympsknLblBlue",
            "text": "Call",
            "top": "48dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "textCopyable": false,
            "wrapping": constants.WIDGET_TEXT_WORD_WRAP
        });
        flxCall.add(imgCall, lblCall);
        var flxSave = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "22%",
            "id": "flxSave",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "33.34%",
            "skin": "CopyslFbox",
            "top": "55%",
            "width": "33.33%",
            "zIndex": 1
        }, {}, {});
        flxSave.setDefaultUnit(kony.flex.DP);
        var imgSave = new kony.ui.Image2({
            "centerX": "50%",
            "centerY": "30%",
            "height": "40dp",
            "id": "imgSave",
            "isVisible": true,
            "left": "12dp",
            "skin": "slImage",
            "src": "kony_mp_map05_save.png",
            "top": "10dp",
            "width": "40dp",
            "zIndex": 1
        }, {
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var lblSave = new kony.ui.Label({
            "centerX": "52%",
            "centerY": "70%",
            "id": "lblSave",
            "isVisible": true,
            "skin": "konympsknLblBlue",
            "text": "Save",
            "top": "48dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "textCopyable": false,
            "wrapping": constants.WIDGET_TEXT_WORD_WRAP
        });
        flxSave.add(imgSave, lblSave);
        var flxShare = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "22%",
            "id": "flxShare",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "66.67%",
            "skin": "CopyslFbox",
            "top": "55%",
            "width": "33.33%",
            "zIndex": 1
        }, {}, {});
        flxShare.setDefaultUnit(kony.flex.DP);
        var imgShare = new kony.ui.Image2({
            "centerX": "50%",
            "centerY": "30%",
            "height": "40dp",
            "id": "imgShare",
            "isVisible": true,
            "left": "12dp",
            "skin": "slImage",
            "src": "kony_mp_map05_share.png",
            "top": "10dp",
            "width": "40dp",
            "zIndex": 1
        }, {
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var lblShare = new kony.ui.Label({
            "centerX": "50%",
            "centerY": "70%",
            "id": "lblShare",
            "isVisible": true,
            "skin": "konympsknLblBlue",
            "text": "Share",
            "top": "48dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "textCopyable": false,
            "wrapping": constants.WIDGET_TEXT_WORD_WRAP
        });
        flxShare.add(imgShare, lblShare);
        var btnNavigate = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerX": "50%",
            "clipBounds": true,
            "height": "10%",
            "id": "btnNavigate",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "47dp",
            "skin": "konympmap05BlueBackgroundRoundCorner",
            "top": "83%",
            "width": "90%",
            "zIndex": 1
        }, {}, {});
        btnNavigate.setDefaultUnit(kony.flex.DP);
        var lblNavigate = new kony.ui.Label({
            "centerY": "50%",
            "id": "lblNavigate",
            "isVisible": true,
            "left": "45%",
            "skin": "konympmap05sknLblWhite",
            "text": "Navigate",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "textCopyable": false,
            "wrapping": constants.WIDGET_TEXT_WORD_WRAP
        });
        var imgNavigate = new kony.ui.Image2({
            "centerY": "50%",
            "height": "15dp",
            "id": "imgNavigate",
            "isVisible": true,
            "left": "38%",
            "skin": "slImage",
            "src": "kony_mp_map05_navigate.png",
            "width": "15dp",
            "zIndex": 1
        }, {
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        btnNavigate.add(lblNavigate, imgNavigate);
        var flxHead = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "21%",
            "id": "flxHead",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "skin": "konympmap05sknFlxWhiteLightBackground",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, {}, {});
        flxHead.setDefaultUnit(kony.flex.DP);
        flxHead.add();
        var imgMain = new kony.ui.Image2({
            "height": "65dp",
            "id": "imgMain",
            "isVisible": true,
            "left": "5.30%",
            "skin": "slImage",
            "src": "kony_mp_map05_image.png",
            "top": "1.95%",
            "width": "70dp",
            "zIndex": 1
        }, {
            "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var lblHeading = new kony.ui.Label({
            "id": "lblHeading",
            "isVisible": true,
            "left": "26%",
            "skin": "konympmap05BlackBold",
            "text": "Bikermann Davis",
            "top": "1.95%",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "textCopyable": false,
            "wrapping": constants.WIDGET_TEXT_WORD_WRAP
        });
        var lblDistance = new kony.ui.Label({
            "id": "lblDistance",
            "isVisible": true,
            "left": "77%",
            "skin": "konympmap05BlackBold",
            "text": "1.2 miles",
            "top": "1.95%",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "textCopyable": false,
            "wrapping": constants.WIDGET_TEXT_WORD_WRAP
        });
        var imgStar1 = new kony.ui.Image2({
            "height": "15dp",
            "id": "imgStar1",
            "isVisible": true,
            "left": "26%",
            "skin": "slImage",
            "src": "kony_mp_map05_star_small.png",
            "top": "7.50%",
            "width": "15dp",
            "zIndex": 1
        }, {
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var imgStar2 = new kony.ui.Image2({
            "height": "15dp",
            "id": "imgStar2",
            "isVisible": true,
            "left": "31%",
            "skin": "slImage",
            "src": "kony_mp_map05_star_small.png",
            "top": "7.50%",
            "width": "15dp",
            "zIndex": 1
        }, {
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var imgStar3 = new kony.ui.Image2({
            "height": "15dp",
            "id": "imgStar3",
            "isVisible": true,
            "left": "36%",
            "skin": "slImage",
            "src": "kony_mp_map05_star_small.png",
            "top": "7.50%",
            "width": "15dp",
            "zIndex": 1
        }, {
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var imgStar4 = new kony.ui.Image2({
            "height": "15dp",
            "id": "imgStar4",
            "isVisible": true,
            "left": "41%",
            "skin": "slImage",
            "src": "kony_mp_map05_star_small.png",
            "top": "7.50%",
            "width": "15dp",
            "zIndex": 1
        }, {
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var imgStar5 = new kony.ui.Image2({
            "height": "15dp",
            "id": "imgStar5",
            "isVisible": true,
            "left": "46%",
            "skin": "slImage",
            "src": "kony_mp_map05_star_inactive.png",
            "top": "7.50%",
            "width": "15dp",
            "zIndex": 1
        }, {
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var lblDescription = new kony.ui.Label({
            "id": "lblDescription",
            "isVisible": true,
            "left": "26%",
            "skin": "konympmap05sknLblBlack",
            "text": "428 Cristopher Stravenue Apt. 495",
            "top": "14%",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "textCopyable": false,
            "wrapping": constants.WIDGET_TEXT_WORD_WRAP
        });
        var line2 = new kony.ui.Label({
            "height": "0.05%",
            "id": "line2",
            "isVisible": true,
            "left": "0dp",
            "skin": "konympmap05sknLblGreyBackground",
            "top": "74%",
            "width": "100%",
            "zIndex": 2
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "textCopyable": false,
            "wrapping": constants.WIDGET_TEXT_WORD_WRAP
        });
        flxMain.add(flxHeader, flxBody, lblOpenHours, lblOpenHoursMonToFri, lblOpenHoursMonToFriValue, lblOpenHoursSatToSun, lblOpenHoursSatToSunValue, line1, flxCall, flxSave, flxShare, btnNavigate, flxHead, imgMain, lblHeading, lblDistance, imgStar1, imgStar2, imgStar3, imgStar4, imgStar5, lblDescription, line2);
        flxParent.add(flxMain);
        var flxOverlay = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "100%",
            "id": "flxOverlay",
            "isVisible": false,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "onTouchStart": controller.AS_FlexContainer_bcb5074d49f046f3b575e1a13a507e0e,
            "skin": "konympmap05BackgroundOverlay",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, {}, {});
        flxOverlay.setDefaultUnit(kony.flex.DP);
        flxOverlay.add();
        var imgBluepin = new kony.ui.Image2({
            "height": "2dp",
            "id": "imgBluepin",
            "isVisible": true,
            "left": "-120%",
            "skin": "slImage",
            "src": "kony_mp_map05_blue_pin.png",
            "top": "200%",
            "width": "2dp",
            "zIndex": 3
        }, {
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        map05.add(mapView, flxParent, flxOverlay, imgBluepin);
        return map05;
    }
})