define(function() {
    var controller = require("com/konymp/map8/usermap8Controller");
    var actions = require("com/konymp/map8/map8ControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    return controller;
});