define(function() {
    var controller = require("com/konymp/map05/usermap05Controller");
    var actions = require("com/konymp/map05/map05ControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    return controller;
});