define(function() {
    return {
        addLocationsToMap: function() {
            this.view.mapLocations.locationData = [{
                lat: "40.748817",
                lon: "-73.985428",
                image: "map_pin_red.png"
            }];
        }
    };
});