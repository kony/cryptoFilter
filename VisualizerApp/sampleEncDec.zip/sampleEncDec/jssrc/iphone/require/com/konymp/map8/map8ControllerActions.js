define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_FlexContainer_ca06db257ab142ee94a1a131164ac122: function AS_FlexContainer_ca06db257ab142ee94a1a131164ac122(eventobject) {
        var self = this;
        this.addLocationsToMap();
    }
});