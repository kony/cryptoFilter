define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_FlexContainer_e787afbd4f7e4426b481bcb5c1749425: function AS_FlexContainer_e787afbd4f7e4426b481bcb5c1749425(eventobject) {
        var self = this;
        this.addLocationsToMap();
    }
});