define(function() {
    return function(controller) {
        var map6 = new kony.ui.FlexContainer({
            "clipBounds": true,
            "isMaster": true,
            "height": "100%",
            "id": "map6",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "preShow": controller.AS_FlexContainer_fb2f0320ae6f493081255b2fb82f57b0,
            "skin": "CopyslFbox1",
            "top": "0dp",
            "width": "100%"
        }, {}, {});
        map6.setDefaultUnit(kony.flex.DP);
        var mapLocations = new kony.ui.Map({
            "calloutWidth": 80,
            "defaultPinImage": "map_pin_red.png",
            "height": "100%",
            "id": "mapLocations",
            "isVisible": true,
            "left": "0%",
            "provider": constants.MAP_PROVIDER_GOOGLE,
            "top": "0%",
            "width": "100%",
            "zIndex": 1
        }, {}, {
            "mode": constants.MAP_VIEW_MODE_NORMAL,
            "showCurrentLocation": constants.MAP_VIEW_SHOW_CURRENT_LOCATION_NONE,
            "zoomLevel": 6
        });
        var flxMapPinDetails = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "bottom": "0%",
            "clipBounds": true,
            "height": "36%",
            "id": "flxMapPinDetails",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "0%",
            "skin": "konympmap6sknFlxMapPinDetails",
            "width": "100%",
            "zIndex": 1
        }, {}, {});
        flxMapPinDetails.setDefaultUnit(kony.flex.DP);
        var lblMapPinName = new kony.ui.Label({
            "id": "lblMapPinName",
            "isVisible": true,
            "left": "5%",
            "skin": "konympmap6sknLblMapPinName",
            "text": "Bickermann Davis",
            "top": "3.40%",
            "width": "90%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "textCopyable": false,
            "wrapping": constants.WIDGET_TEXT_WORD_WRAP
        });
        var lblMapPinDistance = new kony.ui.Label({
            "id": "lblMapPinDistance",
            "isVisible": true,
            "left": "5%",
            "skin": "konympmap6sknLblMapPinDistance",
            "text": "1.2 Miles",
            "top": "3%",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "textCopyable": false,
            "wrapping": constants.WIDGET_TEXT_WORD_WRAP
        });
        var lblMapPinAddress = new kony.ui.Label({
            "height": "32%",
            "id": "lblMapPinAddress",
            "isVisible": true,
            "left": "5%",
            "skin": "konympmap6sknLblMapPinDistance",
            "text": "14787 N. Scottsdale Road\nSuite 408\nScottsdale, AZ 547874\nUSA",
            "top": "7%",
            "width": "90%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "textCopyable": false,
            "wrapping": constants.WIDGET_TEXT_WORD_WRAP
        });
        var flxNavigate = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "20%",
            "id": "flxNavigate",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "5%",
            "skin": "CopyslFbox1",
            "top": "6%",
            "width": "90%",
            "zIndex": 1
        }, {}, {});
        flxNavigate.setDefaultUnit(kony.flex.DP);
        var btnNavigate = new kony.ui.Button({
            "centerX": "50%",
            "focusSkin": "konympmap6sknBtnNavigateFocus",
            "height": "100%",
            "id": "btnNavigate",
            "isVisible": true,
            "left": "0%",
            "skin": "konympmap6sknBtnNavigate",
            "text": "Navigate",
            "top": "0%",
            "width": "100%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "displayText": true,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "showProgressIndicator": true
        });
        var imgNavigate = new kony.ui.Image2({
            "centerY": "50%",
            "height": "28dp",
            "id": "imgNavigate",
            "isVisible": true,
            "left": "30%",
            "skin": "CopyslImage",
            "src": "navigate_arrow.png",
            "width": "28dp",
            "zIndex": 1
        }, {
            "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flxNavigate.add(btnNavigate, imgNavigate);
        flxMapPinDetails.add(lblMapPinName, lblMapPinDistance, lblMapPinAddress, flxNavigate);
        map6.add(mapLocations, flxMapPinDetails);
        return map6;
    }
})