define(function() {
    var controller = require("com/konymp/map6/usermap6Controller");
    var actions = require("com/konymp/map6/map6ControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    return controller;
});