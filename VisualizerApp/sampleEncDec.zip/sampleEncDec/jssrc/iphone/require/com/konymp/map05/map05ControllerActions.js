define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Map_a4e71df2f34e4ca2b0458fbadc02c8e3: function AS_Map_a4e71df2f34e4ca2b0458fbadc02c8e3(eventobject, location) {
        var self = this;
        this.pinClicked(location);
    },
    AS_FlexContainer_fd62abe9b95343e4891e7b7d4c81f070: function AS_FlexContainer_fd62abe9b95343e4891e7b7d4c81f070(eventobject, x, y) {
        var self = this;
        this.animateFlexToFull();
    },
    AS_FlexContainer_b1697257ac6b424789b3e8ebce21f5ac: function AS_FlexContainer_b1697257ac6b424789b3e8ebce21f5ac(eventobject, x, y) {
        var self = this;
        var a = 1;
    },
    AS_FlexContainer_bcb5074d49f046f3b575e1a13a507e0e: function AS_FlexContainer_bcb5074d49f046f3b575e1a13a507e0e(eventobject, x, y) {
        var self = this;
        this.animateFlexToSmall();
    },
    AS_FlexContainer_ec0cbdcd58ed443788cf8ebd99b42932: function AS_FlexContainer_ec0cbdcd58ed443788cf8ebd99b42932(eventobject) {
        var self = this;
        this.addDataToMap();
    }
});