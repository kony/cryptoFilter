define(function() {
    var controller = require("com/konymp/map7/usermap7Controller");
    var actions = require("com/konymp/map7/map7ControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    return controller;
});