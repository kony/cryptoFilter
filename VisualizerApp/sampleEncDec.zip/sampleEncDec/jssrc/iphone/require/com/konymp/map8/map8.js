define(function() {
    return function(controller) {
        var map8 = new kony.ui.FlexContainer({
            "clipBounds": true,
            "isMaster": true,
            "height": "100%",
            "id": "map8",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "preShow": controller.AS_FlexContainer_ca06db257ab142ee94a1a131164ac122,
            "skin": "CopyslFbox3",
            "top": "0dp",
            "width": "100%"
        }, {}, {});
        map8.setDefaultUnit(kony.flex.DP);
        var mapLocations = new kony.ui.Map({
            "calloutWidth": 80,
            "defaultPinImage": "map_pin_red.png",
            "height": "100%",
            "id": "mapLocations",
            "isVisible": true,
            "left": "0%",
            "provider": constants.MAP_PROVIDER_GOOGLE,
            "top": "0%",
            "width": "100%",
            "zIndex": 1
        }, {}, {
            "mode": constants.MAP_VIEW_MODE_NORMAL,
            "showCurrentLocation": constants.MAP_VIEW_SHOW_CURRENT_LOCATION_NONE,
            "zoomLevel": 6
        });
        map8.add(mapLocations);
        return map8;
    }
})