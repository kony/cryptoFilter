define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_FlexContainer_fb2f0320ae6f493081255b2fb82f57b0: function AS_FlexContainer_fb2f0320ae6f493081255b2fb82f57b0(eventobject) {
        var self = this;
        this.addLocationsToMap();
    }
});