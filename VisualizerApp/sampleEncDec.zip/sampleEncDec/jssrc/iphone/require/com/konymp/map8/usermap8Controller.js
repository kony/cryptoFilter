define(function() {
    return {
        addLocationsToMap: function() {
            this.view.mapLocations.locationData = [{
                lat: "40.748817",
                lon: "-73.985428",
                image: "map_pin_red.png"
            }, {
                lat: "42.361145",
                lon: "-71.057083",
                image: "map_pin_red.png"
            }, {
                lat: "39.952583",
                lon: "-75.165222",
                image: "map_pin_red.png"
            }, {
                lat: "41.763710",
                lon: "-72.685097",
                image: "map_pin_red.png"
            }, {
                lat: "41.512177",
                lon: "-74.018326",
                image: "map_pin_red.png"
            }, {
                lat: "42.652580",
                lon: "-73.756233",
                image: "map_pin_red.png"
            }, {
                lat: "40.610306",
                lon: "-75.477104",
                image: "map_pin_red.png"
            }, {
                lat: "42.452858",
                lon: "-75.063774",
                image: "map_pin_red.png"
            }, {
                lat: "41.408970",
                lon: "-75.662415",
                image: "map_pin_red.png"
            }];
        }
    };
});