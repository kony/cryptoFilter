define("flxOutr", function() {
    return function(controller) {
        var flxOutr = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "15%",
            "id": "flxOutr",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "skin": "slFbox"
        }, {}, {});
        flxOutr.setDefaultUnit(kony.flex.DP);
        var flxBody = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerX": "50%",
            "centerY": "50%",
            "clipBounds": true,
            "height": "94%",
            "id": "flxBody",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "skin": "CopyslFbox0bde7642ad02740",
            "width": "98%",
            "zIndex": 1
        }, {}, {});
        flxBody.setDefaultUnit(kony.flex.DP);
        var lblName = new kony.ui.Label({
            "id": "lblName",
            "isVisible": true,
            "left": "5%",
            "skin": "CopyslLabel0hb05a671505041",
            "text": "Label",
            "top": "5%",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "textCopyable": false,
            "wrapping": constants.WIDGET_TEXT_WORD_WRAP
        });
        var lblAcNum = new kony.ui.Label({
            "id": "lblAcNum",
            "isVisible": true,
            "left": "5%",
            "skin": "CopyslLabel0i821dec17a4b4a",
            "text": "Label",
            "top": "50%",
            "width": "40%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "textCopyable": false,
            "wrapping": constants.WIDGET_TEXT_WORD_WRAP
        });
        var lblBal = new kony.ui.Label({
            "id": "lblBal",
            "isVisible": true,
            "right": "5%",
            "skin": "CopyslLabel0de17cae33bbd42",
            "text": "Label",
            "top": "50%",
            "width": "40%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "textCopyable": false,
            "wrapping": constants.WIDGET_TEXT_WORD_WRAP
        });
        flxBody.add(lblName, lblAcNum, lblBal);
        flxOutr.add(flxBody);
        return flxOutr;
    }
})