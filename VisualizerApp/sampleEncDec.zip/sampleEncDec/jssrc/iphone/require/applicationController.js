define({
    appInit: function(params) {
        skinsInit();
        kony.mvc.registry.add("com.konymp.map05", "map05", "map05Controller");
        kony.application.registerMaster({
            "namespace": "com.konymp",
            "classname": "map05",
            "name": "com.konymp.map05"
        });
        kony.mvc.registry.add("com.konymp.map6", "map6", "map6Controller");
        kony.application.registerMaster({
            "namespace": "com.konymp",
            "classname": "map6",
            "name": "com.konymp.map6"
        });
        kony.mvc.registry.add("com.konymp.map7", "map7", "map7Controller");
        kony.application.registerMaster({
            "namespace": "com.konymp",
            "classname": "map7",
            "name": "com.konymp.map7"
        });
        kony.mvc.registry.add("com.konymp.map8", "map8", "map8Controller");
        kony.application.registerMaster({
            "namespace": "com.konymp",
            "classname": "map8",
            "name": "com.konymp.map8"
        });
        kony.mvc.registry.add("flxOutr", "flxOutr", "flxOutrController");
        kony.mvc.registry.add("Form0d15312a7146f4b", "Form0d15312a7146f4b", "Form0d15312a7146f4bController");
        kony.mvc.registry.add("frmAddAc", "frmAddAc", "frmAddAcController");
        kony.mvc.registry.add("frmMain", "frmMain", "frmMainController");
        kony.application.setCheckBoxSelectionImageAlignment(constants.CHECKBOX_SELECTION_IMAGE_ALIGNMENT_RIGHT);
        kony.application.setDefaultTextboxPadding(false);
        kony.application.setRespectImageSizeForImageWidgetAlignment(true);
        setAppBehaviors();
        if (typeof startBackgroundWorker != "undefined") {
            startBackgroundWorker();
        }
    },
    postAppInitCallBack: function() {},
    appmenuseq: function() {
        new kony.mvc.Navigation("frmMain").navigate();
    }
});