define({
    "onClickAdd": function() {
        var ddd = new Date();
        var data = {
            "grade": "a",
            "name": this.view.txtName.text,
            "contact": this.view.txtBalance.text
        };
        //alert("actual data :"+JSON.stringify(data));
        var enData = caesarEncrypt(JSON.stringify(data));
        var toBeSent = {
            "enData": enData
        };
        alert("encrypted :" + JSON.stringify(toBeSent));

        function successCB(dataModel) {
            var userDataObject = new kony.sdk.dto.DataObject("crtStdnt");
            userDataObject.setRecord(toBeSent);
            var params = {
                "dataObject": userDataObject
            };
            dataModel.create(params, function(successResponse) {
                kony.model.ApplicationContext.dismissLoadingScreen();
                alert("created successfully!!!!");
            }, function(errorResponse) {
                kony.model.ApplicationContext.dismissLoadingScreen();
                alert("failure" + JSON.stringify(errorResponse));
            });
            alert("decrypted  :" + caesarDecrypt(toBeSent.d));
        }

        function errorCB(err) {
            kony.model.ApplicationContext.dismissLoadingScreen();
            alert("error in create model" + JSON.stringify(err));
        }
        try {
            kony.model.ApplicationContext.createModel("crtStdnt", "StudentWithPP", {
                "access": "online"
            }, {}, successCB, errorCB);
        } catch (exp) {
            kony.model.ApplicationContext.dismissLoadingScreen();
            alert("Exception while creating data model");
        }
    },
    "AS_Button_jba5d06ff0934494bd2af5a3628d7b71": function AS_Button_jba5d06ff0934494bd2af5a3628d7b71(eventobject) {
        var self = this;
        this.onClickAdd();
    }
})