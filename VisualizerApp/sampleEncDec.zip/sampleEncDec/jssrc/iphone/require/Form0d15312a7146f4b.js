define("Form0d15312a7146f4b", function() {
    return function(controller) {
        function addWidgetsForm0d15312a7146f4b() {
            this.setDefaultUnit(kony.flex.DP);
            var map8 = new com.konymp.map8({
                "clipBounds": true,
                "id": "map8",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "skin": "CopyslFbox3",
                "top": "0%",
                "zIndex": 1
            }, {}, {});
            map8.left = "0%";
            map8.top = "0%";
            map8.zIndex = 1;
            map8.mapLocations.left = "0%";
            map8.mapLocations.top = "0%";
            this.add(map8);
        };
        return [{
            "addWidgets": addWidgetsForm0d15312a7146f4b,
            "enabledForIdleTimeout": false,
            "id": "Form0d15312a7146f4b",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": true,
            "skin": "slForm"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "configureExtendBottom": false,
            "configureExtendTop": false,
            "configureStatusBarStyle": false,
            "footerOverlap": false,
            "formTransparencyDuringPostShow": "100",
            "headerOverlap": false,
            "inputAccessoryViewType": constants.FORM_INPUTACCESSORYVIEW_CANCEL,
            "needsIndicatorDuringPostShow": false,
            "retainScrollPosition": false,
            "titleBar": true,
            "titleBarConfig": {
                "renderTitleText": true,
                "prevFormTitle": false,
                "titleBarLeftSideView": "button",
                "labelLeftSideView": "Back",
                "titleBarRightSideView": "button",
                "labelRightSideView": "Edit"
            },
            "titleBarSkin": "slTitleBar"
        }]
    }
});