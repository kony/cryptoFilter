var plainSpace = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'];
var cipherSpace = ['D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','A','B','C'];
function ceasarEncrypt(plainText) {
  var cipherText = "";
  for (var i = 0; i < plainText.length; i++) {
    if(plainSpace.indexOf((plainText.charAt(i)).toLowerCase())!=-1){
      cipherText += cipherSpace[plainSpace.indexOf((plainText.charAt(i)).toLowerCase())];
    }else{
      cipherText += plainText.charAt(i);
    }
  }
  //alert("Encrypted :"+cipherText);
  return cipherText;
}
function ceasarDecrypt(cipherText) {
  var plainText = "";
  for (var i = 0; i < cipherText.length; i++) {
    if(cipherSpace.indexOf(((cipherText.charAt(i)).toUpperCase()))!=-1){
      plainText += plainSpace[cipherSpace.indexOf(((cipherText.charAt(i)).toUpperCase()))];
    }else{
      plainText += cipherText.charAt(i);
    }
  }
  //alert("in decrypt:"+plainText);
  return plainText;
}