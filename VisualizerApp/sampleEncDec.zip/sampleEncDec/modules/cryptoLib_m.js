//Type your code here
function caesarEncrypt (msg) {
  var encyptd = "";
  for (var i = 0 ; i < msg.length; i++) {
    encyptd = encyptd + String.fromCharCode(msg.charCodeAt(i) + 3) ;
  }
  return encyptd;
}
function caesarDecrypt(msg){
  var decyptd = "";
  for (var i = 0 ; i < msg.length; i++) {
    decyptd = decyptd + String.fromCharCode(msg.charCodeAt(i) - 3) ;
  }
  return decyptd;	
}