/*
 * Model Extension class for cust_profile object under Accounts object service group
 * Developer can add validation logic here
 *
 */

kony = kony || {};
kony.model = kony.model || {};
kony.model.Accounts = kony.model.Accounts || {};
/**
 * Creates a new Model Extension.
 * @class cust_profileModelExtension
 * @param {Object} modelObj - Model.
 */
kony.model.Accounts.cust_profileModelExtension = (function(){
    function cust_profileModelExtension(modelObj) {
        var model = modelObj;

        this.getModel = function() {
            return model;
        };
        this.setModel = function(modelObj) {
            model = modelObj;
        };

    }
    
    /**
     * This is called from create and update methods of Model class.
     * This method is a handle to custom validation written by developer.
     * @memberof cust_profileModelExtension#
     * @param {Object} dataObject - Data object.
     * @param {kony.model.ValidationType} validationType - Create/Update.
     * @returns {Boolean} - whether data is valid
     */
    cust_profileModelExtension.prototype.validate = function(dataObject, validationType) {
        //TO-DO add custom validation
        return true;
    }
	
	return cust_profileModelExtension;
})();